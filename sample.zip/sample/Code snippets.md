```csharp

public void ConfigureServices(IServiceCollection services)
{
  services.AddAuthorization(options => {
    // Define a global policy
    options.AddPolicy("GlobalPolicy", policy =>
      policy.RequireAuthenticatedUser() // example: require the user to be authenticated
            .RequireRole("Admin")); // example: require the user to be in the "Admin" role
    });

    services.AddControllers();
}

```