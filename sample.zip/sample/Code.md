Check how it works with source code snippets and horizontal scrolling

```csharp
interface IProvider
{
	Task Initialize(string name, bool swallowExceptions, IConfiguration configuration, DbContextOptions<DataCotext> options);
	
	Task<bool> GrabData();
}
```