## References

- [Site](https://edwarddonner.com/2025/04/21/the-complete-agentic-ai-engineering-course/)
- [Github repository](https://github.com/ed-donner/agents)
- [Slides](https://docs.google.com/document/d/1rf3ft6XsEhvixytTtYLZWVLJgySsBhp0tqlxWDCyoNA/edit?usp=sharing)

## Comparing AI Agents Frameworks - Simplicity vs Power

- No framework, MCP
  Full control, *low* level APIs
- OpenAI Agents SDK, Crew AI
- LangGraph, AutoGen
  Steeper learning curve, great power
  *Coupled* to the framework, less direct interaction with LLMs

Which one you pick depends on use case and personal preferences (e.g., how much you are comfortable with abstractions)

## Resources vs Tools

- **Resources**: Shoving data relevant to the question into the prompt: in the end, we put extra content in the prompt.
  You can use techniques like RAG and add **focused** content.
  This content is part of the [[system prompt|#system-prompt-vs-user-prompt]]
- **Tools**: give an LLM the power to carry out actions like query a database, or message other LLMs
  How does it work?

  In theory, it's the LLM that should perform the query, but what happens in practice is different: the client will tell the LLM if the LLM wants the client to perform some action on its behalf, and send the response (or result , depending on the action) back to the LLM.

  So when configuring the LLM, you tell what it is able to ask for: if the LLM response ask you to do something, you (your code) executes the action, and send the result back to the LLM.

  LLS, using tools means telling the LLM he can ask the client to do some specific action, and the client will send back the result to the LLM, which will use this additional data for additional processing.

  The LLM is instructed on which tools are available via json (apparently, just OpenAPI specs/json schemas): the LLM can answer with a reply that asks the client to run one of the tools it has been been informed of;

## System Prompt vs User Prompt

- **System prompt** is more about the overall instructions for the LLM: what it is expected to do, and what tools and resources it has.
- **User prompt** is the actual question coming from the user

So we could say the system prompt is similar to a handbook an employee is given by his employer, and explains what and how the employee is expected to serve users or perform his tasks.

## OpenAI Agents SDK

- Lightweight
- Opinionated
- Making common activities easy (e.g., using tools)

### Concepts

- **Agents** represent LLMs
   Each agent is an LLM with one particular **system** prompt design to organize it around one particular task; in other words, it is not expected to be asked generic question (like ChatGPT for example), rather question on a specific topic or area.
- **Handoffs** represent interactions between agents
- **Guardrails** represent controls
  There are input and output guardrails

### A practical examples

> This is from `2_lab2.ipynb` (day 2) in the repository

A simple workflow where you configure 3 AI agents as sales agents, but with different personalities, i.e.,

  - the first one is "cold and formal"
  - the second is friendly
  - The last one is a "busy" agent, so usually go straight to the point

You ask each one the same question, i.e., prepare an email to introduce an offer to a customer; the requests will be sent in "parallel".

You then add a fourth agent, and ask it to choose the message most likely the receiver will reply to

So far nothing specifically requires Agent SDK (except for sending the request "in parallel"): but this just already shows some details can be ignored (e.g., json processing)

We can try to extend it with tools, like sending the chosen email.

We can turn a function into a tool, decorating it with @function_tool; but we can also turn a full agent into a tool, just calling `as_tool` on an agent: the returned value is now a *tool*.

When an agent is converted into a tool, what happens it that all the json required to interact with this new tool is generated, and we can treat it as a simple tool to be used by another agent; in other words, it is a wrapper around the agent.

### More on **Handoffs**

**Handoffs** refer to the action of asking something another agent; so they are quite similar to tools created via `as_tool` (as we saw earlier); there are two main differences though:

- From a conceptual viewpoint, a handoff means an agent *explicitly* delegates another agent, rather than using some feature (i.e., tools) to help complete its job

- A more fundamental, simple technical difference is that, when you're using tools, it's more like a request/response pattern, and once you get the response, the main agent continues executing its task; when using handoff instead, you've done your part, and you **pass control** to another agent: the flow does not come back to you again

### Another concrete example

We want to

- get a subject for an email we're going to send,
- then, convert the text (plain text or markdown) to HTML
- finally, send the email

We create two agents, and convert both as tool; we also have a tool to send an email (using some 3rd party service, e.g. SendGrid).

Then we run instruct (via system prompt) our agent to use the first tool (subject writer), then the second tool, and finally send the email.

> In this implementation, our *ancillary* agents are used as tool.

We can now use this **new** agent from the first one, to have a full workflow; in this workflow:

- The first agent uses four tools (three agents to generate email, one to choose the "best" one) to get an email
- then, control is passed (the **handoff**) to the second agent (defined here) to

  - Get a subject,
  - Convert the email to HTML
  - Send the email

  > This second agent is passed as handoff when configuring the first one.

### Guardrails

Guardrails are controls that can be applied at the input or output of the first agent, or the output of the last agent; they're user, for example, to prevent inappropriate input being sent to the model, or block output that is not meant to be shown to the user.

They are implemented as agents.

## CrewAI

- **CrewAI Enterprise** is a multi-agent platform for deploying, running and monitoring Agentic AI
- **CrewAI Studio** is a no-code/lo-code product for creating multi-agent solutions
- **CrewAI open-source framework** is a "framework to orchestrate high performing AI agents with ease and scale"

We're focusing on the 3rd product.

### Core concepts

- **Agent**: an autonomous unit, with an LLM, a role, a goal, a backstory (kind of "context"), memory and tools
- **Task**: a specific assignment to be carried out, with a description, expected output, assigned to an agent
- **Crew**: a term of agents and tasks, either:
  - Sequential, which runs tasks in the order they are defined
  - Hierarchical: use a Manager LLM to assign a tasks to an agent

> It's a bit more opinionated than OpenAI Agents SDK: for example, instead of *generic* instruction (system prompt) an agent has a "role, a goal and a backstory" (see above) the system prompt is constituted from: it's much more prescriptive.

It uses yaml-based configuration, which helps keep actual code and configuration (e.g. role, goal, etc).

> Look at https://serper.dev

## LangGraph

**LangChain** vs **LangGraph**: how do they relate to each other?

- LangChain is one of the earliest abstraction framework, predates recent explosion and works as simplistic levels; now almost everything can expose a MPC, so the need for this layer is somehow less important, and the focus has shifted (or is shifting) to agentic programming.

- LangGraph is a separate offering, from the same company, independent from LangChain; it is a platform focused on stability and predictability in solving problems involving a lot of interconnected processes; it is a framework that helps you organizing your thinking around a workflow of different activities.

There's a third player, LangSmith, which allow you to monitor LangGraph.

> You could use LangChain to build your workflow, but LangGraph is superior and more specific, since it has been built for that from the beginning.

**LangGraph** itself is a suite of three product:

- LangGraph, the framework itself
- LangGraph Studio, a UI tool (visual builder)
- LangGraph Platform, the hosted solution for deploying and running your agents **at scale**.

> See [Building Effective Agents](https://www.anthropic.com/engineering/building-effective-agents)

### Definitions

- Agent workflows are represented as **graphs**
- **State** represents the current snapshot of the application
- **Nodes** ar python functions that represent agent logic

  They receive the **current state** as input, do something, and return an **updated state**

- **Edges** are python functions that determine which **node** to execute next, based on the **state**

  They can be *conditional* or *fixed*

> - Nodes do the work
> - Edges choose what to do next

To start a graph:

- Define the state class
- Start the graph builder
- Create a node
- create edges
- Compile the graph

These steps happen **before** you run your code.

#### More on the **State**

State is **immutable**: you do not update the state you receive: you returns a new instance of the one you've received, with the changes you've applied; the copy you've been given is not altered.

A special function, a **reducer**, is used to combine the existing state with the changes, to produce the new state, for each field in the state you';'re going to update.

> **TODO** (for me): verify this latest point

> Using a reducer allows LangGraph to run multiple nodes concurrently, and combine state without overwriting

LangGraph needs **annotations** for reducers.
  

```python

from typing import Annotated
from langgraph.graph import StateGraph
from langgraph.graph.messages import add_messages
from pydantic import BaseModel

class State(BaseModel):

    # add_messages is a built-in reducer, provided by LangGraph itself
    # without annotation, and just the type hint, this would be `messages: List`
    messages: Annotated[List, add_messages]
```

> By itself, LangGraph has nothing to do with LLM: edges and graphs are simply python functions.

### Super-Steps

- A super-step is a single iteration over the graph nodes: the graph describes one super-step; one interaction between agents and tools to achieve an outcome.

- Every user interaction is a fresh `graph.invoke(state)` call

- The reducer handles updating state **during a super-step**, but **not between super-steps**

We want to preserve memory **between** super-steps, ie. between calls to `graph.invoke`.

What this means is: imagine we have a chat: a user sends its prompt, and the bot (LLM) replies. the next interaction is another, different call to `graph.invoke`, which normally would not know anything about the previous messages.

What we what is to be able to pass the state (i.e. requests and replies) from ane interaction (i.e., graph execution) to the next one, and so on.

### Tools

LangChain can be used to simplify and reduce the amount of code we have to write, e.g. to define our model and process the returned json.

> **TODO**: clarify this, with the help of `4_langgraph/2-lab2.ipynb` (week 4, day 3).

### CheckPointing

*Checkpointing* is the way LangGraph can persist memory (i.e., state) between state, so that subsequent iterations over the graph nodes can benefit from previous interactions.

This can be achieved by creating a `MemorySaver`, and passing it to the graph_builder when the graph is built, e.g.

```python
# create MemorySaver
memory = MemorySaver()

# ... more code

# then make it available to our graph
graph = graph_builder.compile(checkpointer=memory)
```

`MemorySaver` is just one possible storage for our state: alternative options are available, e.g. to store it in SQLite, using `SqliteSaver`.